using System;

namespace GameLauncher
{
	public delegate void ShowMessage(string message, string header);
}