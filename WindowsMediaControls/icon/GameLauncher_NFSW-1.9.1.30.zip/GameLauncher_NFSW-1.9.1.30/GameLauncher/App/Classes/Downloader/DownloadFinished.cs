using System;

namespace GameLauncher
{
	public delegate void DownloadFinished();
}