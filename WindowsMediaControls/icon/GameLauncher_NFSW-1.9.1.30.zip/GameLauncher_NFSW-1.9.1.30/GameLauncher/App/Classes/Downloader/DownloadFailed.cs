using System;

namespace GameLauncher
{
	public delegate void DownloadFailed(Exception ex);
}