# GameLauncher_NFSW [![Build Status](https://travis-ci.org/SoapboxRaceWorld/GameLauncher_NFSW.svg?branch=master)](https://travis-ci.org/SoapboxRaceWorld/GameLauncher_NFSW)
A Rewrite of GameLauncher taken from Need For Speed: World

## Todo
- [X] Downloader?
- [ ] Validate files (sha1?)
- [X] Complete UI
- [X] Original fonts

### Screenshot
![](screenshot.png)

(Status as of `03.05.2018 5:25 GMT+2`)
