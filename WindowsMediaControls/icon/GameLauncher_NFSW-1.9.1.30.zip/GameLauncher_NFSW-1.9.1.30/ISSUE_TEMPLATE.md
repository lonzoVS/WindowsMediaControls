- **Launcher Version:** 
- **Operating system:** 
- **Antivirus/Firewall (if any):** 
- **Wine/Mono Version (if any):** 

**Description of issue:**
```
Error description goes here
```

**JIT Error (if any)**
```
Please embed it inside code tag. Otherwise, delete this line or just type "none"
```